# random_steely_dan

A Chrome extension which displays a random Steely Dan lyric snippet at some random time every 8 hours. And then [tweets it](https://twitter.com/randomsteelydan)


